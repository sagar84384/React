import React, { Component } from 'react';
//import for bootstrap
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
//importing dependencies for router
import { BrowserRouter, Route, Switch } from 'react-router-dom';
//Imports for all components  
import './App.css';
import Home from './components/Home';
import ShopAndCompare from './components/ShopAndCompare';
import Error from './components/Error';
import SeeIfYouQualify from './components/SeeIfYouQualify';
import Header from './components/Header' 
import Footer from './components/Footer';


class App extends Component {
componentWillMount(){
}

  render() {
    return ( 
      <>     
{/*       basic route of application */}
        <BrowserRouter>
        <Header title="Health insurance that’s right for you"/>
        <div className="contentCSS">
            <Switch>
{/*               route for the default component that gets loaded at homePage */}
             <Route path="/"  component={Home} exact/>
             <Route path="/see-if-you-qualify-for-financial-help/" component={SeeIfYouQualify}/>
             <Route path="/shopandcompare" component={ShopAndCompare}/>
             <Route component={Error}/>
           </Switch>
        </div> 
      </BrowserRouter> 
      <Footer/>
      </>
    );
  }
}
 
export default App;