import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
          <div className="footercss footer">
 
     <p  >CoveredCA.com is sponsored by <a href="http://hbex.coveredca.com/">Covered California</a> and the <a href="http://www.dhcs.ca.gov/Pages/default.aspx" >Department of Health Care Services</a>, which work together to support health insurance  shoppers to get the coverage and care that’s right for them.</p>
    <b className="fontBold"> Copyright © 2019 Covered California</b>
  </div>
        );
    }
}

export default Footer;