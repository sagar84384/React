import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
class Header extends Component {

  
  render() {
    return (
      <div className="logo_div">
        <div className="width50">
          <NavLink to="/" className="navLink logo__link" />
        </div>
        <div className="width50 welcome" >
           <p>{this.props.title}</p>
        </div>
      </div>
    );
  }
}

export default Header;