import React from 'react';
import { NavLink } from 'react-router-dom';
const home = () => {
  return (
    <div className="container homec">
      <div className="optcon">
        <NavLink className="navLink homeOption homeOption1" to="/see-if-you-qualify-for-financial-help/">
          See If You Qualify for Financial Help</NavLink>
        <NavLink className="navLink homeOption homeOption1" to="/shopandcompare">Shop and Compare</NavLink>

        <NavLink className="navLink homeOption homeOption1" to="/viewPlans">Apply for special Enrollment</NavLink>


        <NavLink className="navLink homeOption homeOption1" to="/viewPlans">Medi-Cal Information</NavLink>
      </div>
    </div>
  );
}

export default home;