import React, { Component } from 'react';

class QualifySuccess extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default QualifySuccess;