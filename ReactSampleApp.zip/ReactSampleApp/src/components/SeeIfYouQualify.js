import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
const request = require('superagent');
class SeeIfYouQualify extends Component {

    constructor(){
        super()
/*         defining state for component */
            this.state={listOfQualifyRange:[{noOfPerson:"1",annualIncome:"$48,560"},{noOfPerson:"2",annualIncome:"$48,560"},{noOfPerson:"3",annualIncome:"$65,840"},
            {noOfPerson:"4",annualIncome:"$83,120"},
            {noOfPerson:"5",annualIncome:"$100,400"},
            {noOfPerson:"6",annualIncome:"$117,680"},
            {noOfPerson:"7",annualIncome:"$134,960"}]}
     }

    componentWillMount(){
        console.log("componentWillmount");    
        request.get("http://10.12.188.26:8080/findAll").end((err,res)=>{
            this.setState({listOfQualifyRange : res.body });
            console.log(this.state) }); 
    }

    componentWillUnmount(){
    console.log("componentWillUnmount");    
    }
    render() {
        return (
            <div className="margin50">
            <div className="qualifyHead">
               <h3 >See If You Qualify for Financial Help</h3>
               <p>Does your household fit into one of these categories?</p>
               </div>
                 <table className="table table-striped" border="1">
                 <thead>
                 <tr>
                    <th>Number of people in your household</th>
                    <th>Annual family income</th>
                 </tr>
                 </thead>
                 <tbody>
                  { //Using the map method to display the list
                      this.state.listOfQualifyRange.map((element) =>{
                     
                   return  <tr>
                      <td>{element.noOfPerson}</td>
                      <td>$0 up to {element.annualIncome}</td>
                   </tr>
                  } )}  
                 </tbody>
                 </table>
     
                 <NavLink to="/"> go to Home</NavLink>
                 </div>
        );
    }
}

export default SeeIfYouQualify;