import React, { Component } from 'react';
import './ShopAndCompare.css'
import { NavLink } from 'react-router-dom';
//using superagent library to make the rest call
const request = require('superagent');
class ShopAndCompare extends Component {
    yearArray=[2019,2018,2017,2016,2015,2014];
    noOfMember =[1,2,3,4,5,6,7,8,9]
    constructor(props) {
        super(props);
        this.state = { income: null,noOfMember:1,year:2019,zipCode:null ,showMessage :null};
        //binding the method with the component 
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleIncome(event) {
        this.setState({ income: event.target.value });
    }

    handleYear(event) {
        this.setState({ year: event.target.value });
    }
    handleMember(event) {
        this.setState({ noOfMember: event.target.value });
    }
    handleZip(event) {
        this.setState({ zipCode: event.target.value });
    }


    handleSubmit(event) {
        console.log(this.state);



         request.get(`http://10.12.188.26:8080/validateEligibility/${this.state.income}/${this.state.noOfMember}`).end((err,res)=>{
            this.setState({
                showMessage : res.text
            });
            console.log(this.state,res.body,res)
           });
           event.preventDefault();


     
        }




    render() {
        return (
            <>
            <div className="dispFlex">
                <div className="dispFlexBasis">
                    <h2>Shop and Compare</h2>
                    <h5>Tell us a little bit about yourself</h5>
                    <h6>he information below will help us determine your potential health coverage program eligibility. You may qualify for help to lower your health care costs.</h6>
                </div>
                <div>
                    <h6>Answer these questions to find out if you qualify for help to lower your health care costs.</h6>
                    <form  className="formView" onSubmit={this.handleSubmit.bind(this)}>
{/*                     //binding the events with the component 
 */}
                        <label className="labelView">
                            Coverage Year
                            <select value={this.state.year} onChange={this.handleYear.bind(this)} required>
                                {this.yearArray.map((e)=><option key={e} value={e}>{e}</option>)}
                           </select>
                        </label>
                        <label className="labelView">
                            What is your Zip Code?
                            <input type="text"  pattern="[0-9]+" title="please enter number only" value={this.state.zipCode} onChange={this.handleZip.bind(this)} required min="10" max="100" />
                        </label>
                        <label className="labelView">
                        What is your total household income per year?
                            <input  type="text" pattern="[0-9]+" title="please enter number only" value={this.state.income} onChange={this.handleIncome.bind(this)} required  min="1"/>
                        </label>

                        <label className="labelView">
                        How many people are in your household?
                        <select value={this.state.noOfMember} onChange={this.handleMember.bind(this)} required>
                        {this.noOfMember.map((e)=><option key={e} value={e}>{e}</option>)}

                        </select>



                        </label>
 

                        <input className="btn" disabled={!this.state.income || !this.state.zipCode} type="submit" value="See My Result" />
                    </form>
                </div>
          
            </div>
                  {this.state.showMessage !=null ? <div className="applyShop">
                  <div className="cograts">{this.state.showMessage}
                  <div className="resultDiv">
                  <NavLink to="/"> go to Home</NavLink>
                  
                  <button className="btn">Apply Now</button>
                  </div>
                  </div>
                  </div>:''}
                  </>
        );
    }
}

export default ShopAndCompare;